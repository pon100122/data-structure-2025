input = [10, 40, 30, 60, 30]

def problem1(input):
    
    mean = 0
    median = 0

   
    total = sum(input)                        
    mean = total // len(input)                
    sorted_list = sorted(input)               
    median = sorted_list[len(input) // 2]     
    result = [0,0]
    
    result[0] = mean
    result[1] = median
    return result

result = problem1(input)

assert result == [34, 30]
print("정답입니다.")
