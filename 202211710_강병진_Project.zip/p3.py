input = [[4, 3, 2, 1],
         [0, 0, 0, 0],
         [0, 0, 9, 0],
         [1, 2, 3, 4]]
N = 4

forest = []

def problem3(input):
    bear_size = 2
    honeycomb_count = 0
    time = 0
    bear_x, bear_y = 0, 0
    # 입력 힌트

    # forest 리스트를 input 리스트로 초기화
    forest = [row[:] for row in input]
    
    # 곰의 초기 위치 찾기
    for i in range(N):
        for j in range(N):
            if forest[i][j] == 9:
                bear_x, bear_y = i, j
                forest[i][j] = 0
    print("곰의 초기 위치 x : {0}, y : {1}".format(bear_x, bear_y))

    # 여기에서부터 코드를 작성하세요.
    from collections import deque

    while True:

        visited = [[False]*N for _ in range(N)]
        q = deque([(bear_x, bear_y, 0)])
        visited[bear_x][bear_y] = True

        candidates = []    
        min_dist = None

        while q:
            x, y, d = q.popleft()
            if min_dist is not None and d > min_dist:
                break

            
            if 1 <= forest[x][y] < bear_size:
                candidates.append((x, y, d))
                min_dist = d  

            
            for dx, dy in [(-1,0),(0,-1),(0,1),(1,0)]:
                nx, ny = x+dx, y+dy
                if 0 <= nx < N and 0 <= ny < N and not visited[nx][ny]:
                    if forest[nx][ny] <= bear_size:
                        visited[nx][ny] = True
                        q.append((nx, ny, d+1))

        
        if not candidates:
            break

        
        candidates.sort(key=lambda t: (t[2], t[0], t[1]))
        nx, ny, dist = candidates[0]

       
        time += dist
        honeycomb_count += 1
        forest[nx][ny] = 0

      
        if honeycomb_count == bear_size:
            bear_size += 1
            honeycomb_count = 0

       
        bear_x, bear_y = nx, ny

    result = time
    return result

result = problem3(input)

assert result == 14
print("정답입니다.")
