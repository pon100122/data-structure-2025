input = ")))()"

def problem2(input):
    open_needed = 0    
    balance = 0        

    for char in input:
        if char == '(':
            balance += 1             
        else: 
            if balance > 0:
                balance -= 1         
            else:
                open_needed += 1      

    close_needed = balance           
    result = open_needed + close_needed
    return result

result = problem2(input)

assert result == 3  
print("정답입니다.")
